
import 'package:ecommerce_app/app/Login_Screen/LoginScreen.dart';
import 'package:flutter/material.dart';



void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: signUp(),
    );
  }
}

class signUp extends StatefulWidget {
  @override
  _signUpState createState() => _signUpState();
}

class _signUpState extends State<signUp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Flutter Ecommerce App"),
      ),
      body: Center(
        child: Container(
          width: 500,
          height: 500,
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 110.0),
                  child: Center(
                      child: Text("Signup Page",style: TextStyle(fontSize: 50,fontWeight: FontWeight.bold,color: Colors.black),)
                  ),

                ),
                Container(
                  height: 30,
                ),
                Padding(
                  //padding: const EdgeInsets.only(left:15.0,right: 15.0,top:0,bottom: 0),
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  child: TextField(
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Enter Your Name',
                        hintText: 'Your First and Last name '),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 15.0, right: 15.0, top: 15, bottom: 0),
                  child: TextField(
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Phone number, email or username',
                        hintText: 'Enter valid email id as abc@gmail.com'),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 15.0, right: 15.0, top: 15, bottom: 0),
                  //padding: EdgeInsets.symmetric(horizontal: 15),
                  child: TextField(

                    obscureText: true,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Password',
                        hintText: 'Enter secure password'),
                  ),
                ),

                SizedBox(
                  height: 65,
                  width: 360,
                  child: Container(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: ElevatedButton(
                        child: Text( 'Sign up ', style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                        onPressed: (){
                          print('Successfully log in ');
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.black,
                        ),

                      ),
                    ),
                  ),
                ),

                SizedBox(
                  height: 50,
                ),
                Container(
                    child: Center(
                      child: Row(
                        children: [

                          Padding(
                            padding: const EdgeInsets.only(left: 62),
                            child: Text('Already a member? '),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(left:1.0),
                            child: InkWell(
                                onTap: (){
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => LoginDemo()));
                                  print('hello');
                                },
                                child: Text('Login', style: TextStyle(fontSize: 14, color: Colors.blue),)),
                          )
                        ],
                      ),
                    )
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
