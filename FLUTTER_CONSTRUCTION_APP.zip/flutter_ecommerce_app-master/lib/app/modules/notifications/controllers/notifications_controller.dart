import 'package:get/get.dart';

class NotificationsController extends GetxController {}
