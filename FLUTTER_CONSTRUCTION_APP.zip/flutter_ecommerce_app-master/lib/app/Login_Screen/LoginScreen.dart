
import 'package:ecommerce_app/app/SignUp_screen/SignUpScreen.dart';
import 'package:ecommerce_app/app/modules/base/views/base_view.dart';
import 'package:ecommerce_app/app/routes/app_pages.dart';
import 'package:ecommerce_app/utils/dummy_helper.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginDemo(),
    );
  }
}

class LoginDemo extends StatefulWidget {
  @override
  _LoginDemoState createState() => _LoginDemoState();
}

class _LoginDemoState extends State<LoginDemo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Despecho"),
      ),
      body: Center(
        child: Container(
          width: 500,
          color: Colors.white,
          height: 500,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 110.0),
                  child: Center(
                      child: Text("Login Page",style: TextStyle(fontSize: 50,fontWeight: FontWeight.bold,color: Colors.black),)
                  ),

                ),
                Container(
                  height: 30,
                ),
                Padding(
                  //padding: const EdgeInsets.only(left:15.0,right: 15.0,top:0,bottom: 0),
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  child: TextField(
                    decoration: InputDecoration(
                        border: OutlineInputBorder(
                        ),
                        labelText: 'Phone number, email or username',
                        hintText: 'Enter valid email id as abc@gmail.com'),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 15.0, right: 15.0, top: 15, bottom: 0),
                  //padding: EdgeInsets.symmetric(horizontal: 15),
                  child: TextField(

                    obscureText: true,
                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: 'Password',
                        hintText: 'Enter secure password'),
                  ),
                ),

                SizedBox(
                  height: 65,
                  width: 360,
                  child: Container(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: ElevatedButton(
                        child: Text( 'Log in ', style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                        onPressed: (){
                           Navigator.push(context, MaterialPageRoute(builder: (context) =>   ));

                          print('Successfully log in ');
                        },
                        style: ElevatedButton.styleFrom(
                          primary: Colors.black,
                        ),

                      ),
                    ),
                  ),
                ),

                SizedBox(
                  height: 50,
                ),
                Container(
                    child: Center(
                      child: Row(
                        children: [

                          Padding(
                            padding: const EdgeInsets.only(left: 62),
                            child: Text('Not a member? '),
                          ),

                          Padding(
                            padding: const EdgeInsets.only(left:1.0),
                            child: InkWell(
                                onTap: (){
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => signUp()));
                                  print('hello');
                                },

                                child: Text('SignUp now', style: TextStyle(fontSize: 14, color: Colors.black87,fontWeight: FontWeight.bold),)),
                          )
                        ],
                      ),
                    )
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}